from flask import Flask

app = Flask(__name__)
app.secret_key = "blaBlAlL/a1234 aA./HGH"